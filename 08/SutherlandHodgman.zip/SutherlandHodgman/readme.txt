                ____________________________________________________
               /    ______                 __    __                /|
       	      /    / ____/                / /   /_/               / |
             /    / /_____  _____________/ /________________     / /
            /    / __  / / / / __  /  __/ __  / / __  / ___/    / /
           /     ___/ / /_/ / / / /__  / / / / / / / / ___/    / /
          /    /_____/_____/_/ /_/____/_/ /_/_/_/ /_/____/    / /
         /                                                   / /
        /     Web : www.sunhine2k.de                        / /    		
       /      Mail: webmaster@sunhine2k.de                 / /
      /___________________________________________________/ /
      \____________________________________________________/


Sutherland-Hodgman-Algorithm Applet:
------------------------------------

This little applet shows how the well-known Sutherland-Hodgman-Algorithm works for clipping a polygon against a rectangle.


How to run the applet:
-----------------------
Just open the file CohenSutherlandApplet.html in your preferred browser.


Instructions:
-------------
Just draw a polygon with the mouse; clicking at your first point again closes the polygon. Then press the Clip-Button to clip the polygon immediately; activating the step-by-step mode shows the clipping at the four sides of the rectangle one after the other.



This is a Netbeans 5.0 project.

Sunshine, Dezember 2007


