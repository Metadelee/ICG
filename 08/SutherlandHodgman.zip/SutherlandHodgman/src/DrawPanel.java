/**
 * Helper class for Sutherland-Hodgman-Algorithm Applet.
 * Extends a JPanel for easier drawing and mouse capturing when inserting points.
 * Does also contain the main algorithm for clipping the polygon!
 *
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 * December 2007
 */

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;


public class DrawPanel extends javax.swing.JPanel {
    
    // width and height of drawpanel
    public static final int WIDTH = 600;
    public static final int HEIGHT = 400;
    
    // the bounds of the clipping rectangle
    public static final int LEFTEDGE = WIDTH / 4;
    public static final int RIGHTEDGE = WIDTH / 4 * 3;
    public static final int TOPEDGE = HEIGHT / 4;
    public static final int BOTTOMEDGE = HEIGHT / 4 * 3;
    
    // give each edge of clipping rectangle an ID
    public static final byte ID_TOPEDGE = 0;
    public static final byte ID_RIGHTEDGE = 1;
    public static final byte ID_BOTTOMEDGE = 2;
    public static final byte ID_LEFTEDGE = 3;
    
    private static final Color BACKCOLOR = new Color(255, 196, 120);     // background color
    
    boolean stepMode = false;
    
    SutherlandHodgmanApplet parentApplet;   // reference to parent applet
    Vector<Point> polygon;                  // polygon painted by user
    Vector<Point> clippedPoly;              // polygon clipped
    private boolean isPolyClosed = false;   // true is polygon is complete
    
    int mouseX = -10;           // current x-position of cursor on panel
    int mouseY = -10;           // current y-position of cursor on panel
    
    /** Creates a new instance of DrawPanel */
    public DrawPanel(SutherlandHodgmanApplet parent) 
    {
        parentApplet = parent;  
        this.setLayout(null);
        this.setBounds(0, 0, WIDTH, HEIGHT);
        this.setBackground(BACKCOLOR);
        
        polygon = new Vector<Point>();
        clippedPoly = new Vector<Point>();
        
        this.addMouseMotionListener(new MouseAdapter()
        {
           public void mouseMoved(MouseEvent event)
           {
               mouseX = event.getX();
               mouseY = event.getY();
               if (!isPolyClosed)
                repaint();
           }
        });
        
        this.addMouseListener(new MouseAdapter()
        {
            public void mouseReleased(MouseEvent event)
            {
                // if we cannot add more points, bye
                if (isPolyClosed) return;
                
                // check if polygon should be closed
                if ( (polygon.size() > 2) && 
                     (Math.abs(event.getX() - polygon.firstElement().x) < 5) &&
                     (Math.abs(event.getY() - polygon.firstElement().y) < 5) )
                {
                    isPolyClosed = true;
                    polygon.add(polygon.firstElement());
                }
                else
                {
                    polygon.add(new Point(event.getX(), event.getY()));
                }
                repaint();
            }
        });
    }
    
    /*
     * Reset all values.
     */
    public void reset()
    {
        this.polygon.clear();
        this.clippedPoly.clear();
        isPolyClosed = false;
        repaint();
    }
    
    /*
     * Paint our panel
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        // fill background
        g.setColor(BACKCOLOR);
        g.fillRect(0,0, this.getWidth(), this.getHeight());
        g.setColor(Color.BLACK);
        
        // draw the clipping rectangle
        g.drawLine(LEFTEDGE, TOPEDGE, RIGHTEDGE, TOPEDGE);           // top edge
        g.drawLine(LEFTEDGE, TOPEDGE, LEFTEDGE, BOTTOMEDGE);        // left edge
        g.drawLine(LEFTEDGE, BOTTOMEDGE, RIGHTEDGE, BOTTOMEDGE);    // bottom edge
        g.drawLine(RIGHTEDGE, TOPEDGE, RIGHTEDGE, BOTTOMEDGE);      // right edge
        
        // draw clipped polygon if available, otherwise the original one
        if (clippedPoly != null && clippedPoly.size() > 0)
        {
            g.setColor(Color.RED); 
            drawPolygon(g, clippedPoly);
            g.setColor(Color.BLACK);
        }
        else
            drawPolygon(g, polygon);
        
        // if polygon is completed or no point is set, work is done
        if (this.isPolyClosed || this.polygon.size() < 1) return;
        
        // draw current line
        g.drawLine(polygon.lastElement().x, polygon.lastElement().y, mouseX, mouseY);
        
        // draw string to close line
        if ( (polygon.size() > 2) && 
             (Math.abs(mouseX - polygon.firstElement().x) < 5) &&
             (Math.abs(mouseY - polygon.firstElement().y) < 5) )
        {
            g.drawString("Closing polygon", mouseX + 5, mouseY + 5);
        }
    }
    
    /*
     * Draw given polygon
     */
    public void drawPolygon(Graphics g, Vector<Point> v)
    {
        // draw the point rectangles
        Point p;
        for (int i = 0; i < v.size(); i++)
        {
            p = v.get(i);
            g.fillRect(p.x - 2, p.y - 2, 5, 5);
        }
        
        // draw the connecting lines
        if (v.size() < 1) return;
        Point p2;
        for (int i = 0; i < v.size() - 1; i++)
        {
            p = v.get(i);
            p2 = v.get(i+1);
            g.drawLine(p.x, p.y, p2.x, p2.y);
        }
    }
    
    /*
     * Calculate the intersection with the given edge of the window
     * edge : edge of the clipping window to calc intersection with
     * p1 : current point
     * p2 : next point
     */
    private Point intersectionPoint(byte EdgeID, Point p1, Point p2)
    {
        //Point resultPoint = new Point();
        if (EdgeID == ID_TOPEDGE)
            return new Point(p1.x + (TOPEDGE - p1.y) * (p2.x - p1.x) / (p2.y - p1.y), TOPEDGE);
        else if (EdgeID == ID_BOTTOMEDGE)
            return new Point(p1.x + (BOTTOMEDGE - p1.y) * (p2.x - p1.x) / (p2.y - p1.y), BOTTOMEDGE);
        else if (EdgeID == ID_RIGHTEDGE)
            return new Point(RIGHTEDGE, p1.y + (RIGHTEDGE - p1.x) * (p2.y - p1.y) / (p2.x - p1.x));
        else if (EdgeID == ID_LEFTEDGE)
            return new Point(LEFTEDGE, p1.y + (LEFTEDGE - p1.x) * (p2.y - p1.y) / (p2.x - p1.x));
        return null;
    }
    
    /*
     * Returns true if given Point p is inside the clipping window considering the given edge of the window
     */
    private boolean isInsideClipWindow(Point p, byte EdgeID, int edgeValue)
    {
        if (EdgeID == ID_TOPEDGE)
            return (p.y >= TOPEDGE);
        else if (EdgeID == ID_BOTTOMEDGE)
            return (p.y <= BOTTOMEDGE);
        else if (EdgeID == ID_LEFTEDGE)
            return (p.x >= LEFTEDGE);
        else if (EdgeID == ID_RIGHTEDGE)
            return (p.x <= RIGHTEDGE);
        else
            return false;           // should never happen!
    }
    
    /*
     * Clip the polygon against the rectangle
     */
    public void clip()
    {
        if (!this.isPolyClosed || polygon.size() < 3) return;
        clippedPoly.clear();
        
        Point p;        // current point
        Point p2;       // next point
        
        // make copy of original polygon to work with
        Vector<Point> workPoly = (Vector<Point>)polygon.clone();
        int[] edgevalues = {TOPEDGE, RIGHTEDGE, BOTTOMEDGE, LEFTEDGE };
        int edge;
        
        // loop through all for clipping edges
        for (byte edgeID = 0; edgeID < 4; edgeID++)
        {
            // just draw current step if we are in stepmode
            checkStepMode(edgeID);
            edge = edgevalues[edgeID];  // get edge value
            clippedPoly.clear();
            for (int i = 0; i < workPoly.size() - 1; i++)
            {
                p = workPoly.get(i);
                p2 = workPoly.get(i+1);
                if (isInsideClipWindow(p, edgeID, edge))
                {
                    if (isInsideClipWindow(p2, edgeID, edge))
                        // here both points are inside the clipping window so add the second one
                        clippedPoly.add(new Point(p2.x, p2.y));
                    else
                    {
                        // the following point is outside so add the intersection point
                        clippedPoly.add(intersectionPoint(edgeID, p, p2));  
                    }
                }
                else
                {
                    // so first point is outside the window here
                    if (isInsideClipWindow(p2, edgeID, edge))
                    {
                        // the following point is inside so add the insection point and also p2
                        clippedPoly.add(intersectionPoint(edgeID, p, p2));  
                        clippedPoly.add(new Point(p2.x, p2.y));
                    }
                }
            }
            // make sure that first and last element are the same, we want a closed polygon
            if (clippedPoly.firstElement() != clippedPoly.lastElement())
                clippedPoly.add(clippedPoly.firstElement());
            // we have to keep on working with our new clipped polygon
            workPoly = (Vector<Point>) clippedPoly.clone();  
        }
        repaint();
    }
    
    
    /*
     * Draw the given edge of the clipping window
     */
    public void drawClipLine(Graphics g, int EdgeID)
    {
        switch (EdgeID)
        {
            case ID_TOPEDGE:  g.drawLine(LEFTEDGE, TOPEDGE, RIGHTEDGE, TOPEDGE);  break;
            case ID_LEFTEDGE: g.drawLine(LEFTEDGE, TOPEDGE, LEFTEDGE, BOTTOMEDGE); break;
            case ID_BOTTOMEDGE: g.drawLine(LEFTEDGE, BOTTOMEDGE, RIGHTEDGE, BOTTOMEDGE); break;
            case ID_RIGHTEDGE : g.drawLine(RIGHTEDGE, TOPEDGE, RIGHTEDGE, BOTTOMEDGE); break;
            default: break;
        }
    }
    
    /*
     * If stepmode is enabled, paint current step and pause applet.
     */
    public void checkStepMode(int edgeID)
    {
        if (this.stepMode) 
        {
            Graphics g = this.getGraphics();
            update(g);
            g.setColor(Color.YELLOW);
            this.drawClipLine(g, edgeID);
            try 
            {
                Thread.sleep(2500);
            }
            catch (InterruptedException ex) { }
        }
    }
    
    public boolean isPolygonClosed() { return this.isPolyClosed; }
}
